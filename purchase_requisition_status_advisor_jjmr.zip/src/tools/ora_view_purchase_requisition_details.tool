{
  "toolId": "100002688038240",
  "$context": {
    "etag": "1"
  },
  "createdBy": "FAI_INGESTION",
  "toolCreatedDate": "2025-05-27",
  "toolCode": "ORA_VIEW_PURCHASE_REQUISITION_DETAILS",
  "name": "View Purchase Requisition Details",
  "description": "This deep link tool enables the employee to view the purchase requisition details.",
  "family": "PRC",
  "product": "SSP",
  "type": "DEEP_LINK",
  "status": "PUBLISHED",
  "seededFlag": true,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "PRC.SSP",
  "specification": {
    "baseObjectCode": "ORA_PRC_SSP_PURCHASEREQUISITIONDEEPLINK",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": []
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}
