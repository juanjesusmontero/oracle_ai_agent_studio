{
  "toolId": "300000349631303",
  "$context": {
    "etag": "1"
  },
  "createdBy": "CURTIS.FEITTY",
  "toolCreatedDate": "2026-10-31",
  "toolCode": "AA_TOOL_BO_AR_TRX",
  "name": "AA_TOOL_BO_AR_TRX",
  "description": "AA_TOOL_BO_AR_TRX is a Business Object tool that enables agents to access and manage accounts receivable transaction data within the financial domain. Use this tool to retrieve or interact with AR transaction records efficiently without requiring human approval.",
  "family": "FIN",
  "product": "OTHER",
  "type": "BUSINESS_OBJECT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "FIN.OTHER",
  "specification": {
    "baseObjectCode": "ORA_FIN_OTHER_AADEMOBOARTRX",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": [
        "getall_receivablesInvoices"
      ]
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}
