{
  "$context": {
    "etag": "1"
  },
  "toolCode": "AA_TOOL_PRC_SUPP_CREATE_02",
  "name": "AA_TOOL_PRC_SUPP_CREATE_02",
  "description": "Supplier creation. Creates one supplier with its address and site in Oracle Fusion. Inputs: Supplier, SupplierNumber, AddressName, AddressLine1, SupplierSite, ProcurementBU, SupplierAddressName. Requires human approval.",
  "family": "PRC",
  "product": "SUPPLIER",
  "type": "BUSINESS_OBJECT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": true,
  "userInputMessage": "Do you approve the creation of this supplier in Oracle Fusion?",
  "subType": "",
  "namespace": "PRC.SUPPLIER",
  "specification": {
    "baseObjectCode": "ORA_PRC_SUPPLIER_AADEMOSUPPLIERCREATION",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": [
        "create_suppliers"
      ]
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}