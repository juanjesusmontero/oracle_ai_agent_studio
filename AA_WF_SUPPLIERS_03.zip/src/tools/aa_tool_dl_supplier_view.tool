{
  "$context": {
    "etag": "1"
  },
  "toolCode": "AA_TOOL_DL_SUPPLIER_VIEW",
  "name": "AA_TOOL_DL_SUPPLIER_VIEW",
  "description": "Supplier View Link. A link that opens the supplier in Oracle Fusion. Requires SupplierNumber, the number of the created supplier (for example 100772-00005).",
  "family": "PRC",
  "product": "SUPPLIER",
  "type": "DEEP_LINK",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "PRC.SUPPLIER",
  "specification": {
    "baseObjectCode": "ORA_PRC_SUPPLIER_SUPPLIERVIEWLINK",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": []
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}