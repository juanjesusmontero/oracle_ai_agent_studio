{
  "$context": {
    "etag": "1"
  },
  "toolCode": "AA_TOOL_SUPPLIERS",
  "name": "AA_TOOL_SUPPLIERS",
  "description": "Retrieve the SupplierId of a supplier by its name (parameter pSupplier).",
  "family": "PRC",
  "product": "OTHER",
  "type": "BUSINESS_OBJECT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "PRC.OTHER",
  "specification": {
    "baseObjectCode": "ORA_PRC_OTHER_AADEMOSUPPLIERS",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": [
        "getall_suppliers"
      ]
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}