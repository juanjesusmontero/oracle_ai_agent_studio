{
  "$context": {
    "etag": "1"
  },
  "toolCode": "AA_TOOL_DL_PO_VIEW_02",
  "name": "AA_TOOL_DL_PO_VIEW_02",
  "description": "View Purchase Order link: opens the Redwood purchase order page. Requires pheader_id, the POHeaderId returned by AA_DEMO_PO_FIND_BO_02.",
  "family": "FIN",
  "product": "OTHER",
  "type": "DEEP_LINK",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "FIN.OTHER",
  "specification": {
    "baseObjectCode": "ORA_PRC_PURCHASING_VIEWPURCHASEORDERDEEPLINK",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": []
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}