{
  "toolId": "300000349614764",
  "$context": {
    "etag": "1"
  },
  "createdBy": "CURTIS.FEITTY",
  "toolCreatedDate": "2026-10-31",
  "toolCode": "AA_DEMO_TOOL_AP_INV",
  "name": "AA_DEMO_TOOL_AP_INV",
  "description": "Looks up one Payables invoice in Oracle Fusion by its invoice number (parameter InvoiceNumber, for example 70803096). Returns the invoice header (supplier, business unit, dates, amount, currency, statuses) and its lines. Use it whenever the user asks about a specific invoice.",
  "family": "FIN",
  "product": "OTHER",
  "type": "BUSINESS_OBJECT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "FIN.OTHER",
  "specification": {
    "baseObjectCode": "ORA_FIN_OTHER_AABOAPINV01",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": [
        "getall_invoices"
      ]
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}