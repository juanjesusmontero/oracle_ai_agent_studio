{
  "$context": {
    "etag": "1"
  },
  "toolCode": "AA_TOOL_SUPP_RULES_02",
  "name": "AA_TOOL_SUPP_RULES_02",
  "description": "Creates one supplier in Oracle Fusion. Inputs: Supplier, SupplierNumber, SupplierTypeCode, TaxOrganizationTypeCode, BusinessRelationshipCode, TaxRegistrationCountryCode.",
  "family": "PRC",
  "product": "SUPPLIER",
  "type": "BUSINESS_OBJECT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "PRC.SUPPLIER",
  "specification": {
    "baseObjectCode": "ORA_PRC_SUPPLIER_AASUPPRULESBO02",
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": [
        "create_supplier"
      ]
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}